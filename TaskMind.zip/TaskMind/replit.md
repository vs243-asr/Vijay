# Lakshya - Personal Study Companion

## Overview

Lakshya is a comprehensive personal productivity and study management application designed for students preparing for competitive exams. The app features a handwritten journal aesthetic with a blue and white color scheme and operates entirely client-side using localStorage - no authentication, accounts, or cloud storage required.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: React hooks with localStorage for persistence
- **Data Fetching**: TanStack Query for server state (minimal usage due to client-only nature)

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Development**: Hot module replacement via Vite middleware
- **Database**: PostgreSQL with Neon Database serverless
- **ORM**: Drizzle ORM with schema-first approach
- **Session Management**: Connect-pg-simple for PostgreSQL session storage

### Storage Strategy
- **Primary Storage**: Browser localStorage for all user data
- **Encryption**: Simple btoa/atob encryption for password-protected sections (Journal and AI Chat)
- **Data Persistence**: No server-side persistence - fully client-side application
- **Database Schema**: PostgreSQL schema defined but currently only used for user management (minimal usage)

## Key Components

### 1. Navigation System
- **Type**: Tab-based navigation with responsive design
- **Implementation**: Centralized state management in main App component
- **Mobile Support**: Collapsible navigation for smaller screens

### 2. Core Features
- **Dashboard**: Overview of daily tasks, timer status, productivity stats, and motivational quotes
- **Pomodoro Timer**: Customizable focus/break durations with notification support
- **Task Management**: CRUD operations with priority levels, deadlines, and subject categorization
- **Syllabus Tracker**: Chapter-wise progress tracking with completion percentages
- **Notes System**: Quick notes with tagging, search, and organization capabilities
- **Progress Analytics**: Study statistics and performance tracking

### 3. Protected Features
- **Journal**: Password-protected personal journal with mood tracking
- **AI Chat**: OpenAI-powered study companion with memory and personality
- **Prayer Section**: Multi-language prayer collection and management

### 4. UI Components
- **Design System**: Shadcn/ui with Radix UI primitives
- **Theming**: CSS custom properties with blue/white color scheme
- **Typography**: Kalam font for handwritten aesthetic, Inter for body text
- **Responsive**: Mobile-first design with breakpoint considerations

## Data Flow

### Client-Side Data Management
1. **Storage Layer**: Custom storage classes for each feature (TaskStorage, SubjectStorage, etc.)
2. **State Management**: React hooks (useState, useLocalStorage) for component state
3. **Data Persistence**: Automatic localStorage sync on data mutations
4. **Data Encryption**: Password-protected sections use simple encryption before storage

### Component Communication
1. **Props**: Parent-child communication for navigation and shared state
2. **Callbacks**: Event handlers passed down for state updates
3. **Local Storage**: Direct access to persisted data across components
4. **Context**: Minimal usage, primarily for toast notifications

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18, React DOM, TypeScript
- **UI Components**: Radix UI primitives (@radix-ui/react-*)
- **Styling**: Tailwind CSS, class-variance-authority, clsx
- **Date Handling**: date-fns for date manipulation and formatting
- **State Management**: TanStack React Query for server state
- **Database**: Drizzle ORM, @neondatabase/serverless, connect-pg-simple

### Development Dependencies
- **Build Tools**: Vite, esbuild for production builds
- **TypeScript**: Full TypeScript support with strict configuration
- **Development**: tsx for TypeScript execution, Replit-specific plugins

### AI Integration
- **OpenAI**: GPT-4o integration for AI study companion
- **Configuration**: Browser-compatible OpenAI client with API key management

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with HMR
- **Server**: Express.js with middleware for API routes
- **Database**: PostgreSQL via Neon Database with connection pooling
- **Environment**: Node.js with ES modules

### Production Build
- **Frontend**: Vite build to `dist/public` directory
- **Backend**: esbuild bundle to `dist/index.js`
- **Static Assets**: Served via Express static middleware
- **Database**: PostgreSQL connection via environment variables

### Key Architectural Decisions

1. **Client-Only Storage**: Chose localStorage over server storage for privacy, simplicity, and no-account requirement
2. **Password Protection**: Implemented simple encryption for sensitive sections without server-side validation
3. **Minimal Backend**: Express server primarily for development setup; core functionality is client-side
4. **Component Architecture**: Monolithic components with internal state management for feature isolation
5. **Styling Approach**: Utility-first CSS with component-level customization via CSS variables
6. **TypeScript Integration**: Strict typing throughout with shared types between client and server

The application prioritizes user privacy, offline functionality, and a journal-like aesthetic while providing comprehensive study management features for competitive exam preparation.