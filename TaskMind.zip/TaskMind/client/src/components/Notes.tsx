import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Search, Pin, Edit3, Trash2, Lock, BookOpen } from "lucide-react";
import { NoteStorage } from "@/lib/storage";
import { Note } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface NotesProps {
  onProtectedAccess: (type: 'journal' | 'aichat') => void;
}

export default function Notes({ onProtectedAccess }: NotesProps) {
  const { toast } = useToast();
  const [notes, setNotes] = useState<Note[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'pinned' | 'recent'>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);
  const [quickNote, setQuickNote] = useState('');
  const [newNote, setNewNote] = useState({
    title: '',
    content: '',
    tags: [] as string[],
    pinned: false,
  });
  const [newTag, setNewTag] = useState('');

  useEffect(() => {
    setNotes(NoteStorage.getNotes());
  }, []);

  const predefinedTags = ['Study', 'Ideas', 'Mathematics', 'Physics', 'Chemistry', 'English', 'Motivation', 'Tips'];

  const filteredNotes = notes.filter(note => {
    // Search filter
    const matchesSearch = !searchTerm || 
      note.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));

    if (!matchesSearch) return false;

    // Category filter
    switch (activeFilter) {
      case 'pinned':
        return note.pinned;
      case 'recent':
        const threeDaysAgo = new Date();
        threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
        return new Date(note.createdAt) > threeDaysAgo;
      default:
        return true;
    }
  });

  const handleQuickSave = () => {
    if (!quickNote.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for your note",
        variant: "destructive",
      });
      return;
    }

    const note = NoteStorage.addNote({
      content: quickNote,
      tags: ['Quick Note'],
      pinned: false,
    });

    setNotes(prev => [note, ...prev]);
    setQuickNote('');
    
    toast({
      title: "Note saved",
      description: "Your quick note has been saved",
    });
  };

  const handleAddNote = () => {
    if (!newNote.content.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for your note",
        variant: "destructive",
      });
      return;
    }

    if (editingNote) {
      NoteStorage.updateNote(editingNote.id, {
        title: newNote.title || undefined,
        content: newNote.content,
        tags: newNote.tags,
        pinned: newNote.pinned,
      });

      setNotes(prev => prev.map(n => 
        n.id === editingNote.id 
          ? { 
              ...n, 
              title: newNote.title || undefined,
              content: newNote.content,
              tags: newNote.tags,
              pinned: newNote.pinned,
              updatedAt: new Date().toISOString(),
            }
          : n
      ));
      
      toast({
        title: "Note updated",
        description: "Your changes have been saved",
      });
    } else {
      const note = NoteStorage.addNote({
        title: newNote.title || undefined,
        content: newNote.content,
        tags: newNote.tags,
        pinned: newNote.pinned,
      });

      setNotes(prev => [note, ...prev]);
      
      toast({
        title: "Note saved",
        description: "Your note has been saved",
      });
    }

    setEditingNote(null);
    setNewNote({ title: '', content: '', tags: [], pinned: false });
    setIsAddDialogOpen(false);
  };

  const handleEditNote = (note: Note) => {
    setEditingNote(note);
    setNewNote({
      title: note.title || '',
      content: note.content,
      tags: [...note.tags],
      pinned: note.pinned,
    });
    setIsAddDialogOpen(true);
  };

  const handleDeleteNote = (id: string) => {
    NoteStorage.deleteNote(id);
    setNotes(prev => prev.filter(n => n.id !== id));
    toast({
      title: "Note deleted",
      description: "The note has been removed",
    });
  };

  const handleTogglePin = (id: string) => {
    const note = notes.find(n => n.id === id);
    if (!note) return;

    const pinned = !note.pinned;
    NoteStorage.updateNote(id, { pinned });
    setNotes(prev => prev.map(n => n.id === id ? { ...n, pinned } : n));
    
    toast({
      title: pinned ? "Note pinned" : "Note unpinned",
      description: pinned ? "Note has been pinned to the top" : "Note has been unpinned",
    });
  };

  const handleAddTag = () => {
    if (!newTag.trim() || newNote.tags.includes(newTag.trim())) return;
    setNewNote(prev => ({
      ...prev,
      tags: [...prev.tags, newTag.trim()]
    }));
    setNewTag('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setNewNote(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handlePredefinedTag = (tag: string) => {
    if (newNote.tags.includes(tag)) return;
    setNewNote(prev => ({
      ...prev,
      tags: [...prev.tags, tag]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800 handwritten">Ideas & Notes</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
              <Plus className="h-4 w-4 mr-2" />
              New Note
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="handwritten">
                {editingNote ? 'Edit Note' : 'Add New Note'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Input
                  value={newNote.title}
                  onChange={(e) => setNewNote(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Note title (optional)..."
                  className="handwritten"
                />
              </div>
              
              <div>
                <Textarea
                  value={newNote.content}
                  onChange={(e) => setNewNote(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Write your note..."
                  className="handwritten min-h-32"
                  rows={6}
                />
              </div>
              
              <div>
                <div className="flex space-x-2 mb-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Add a tag..."
                    onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                    className="flex-1"
                  />
                  <Button onClick={handleAddTag} size="sm">Add</Button>
                </div>
                
                <div className="flex flex-wrap gap-2 mb-2">
                  {predefinedTags.map(tag => (
                    <Button
                      key={tag}
                      variant="outline"
                      size="sm"
                      onClick={() => handlePredefinedTag(tag)}
                      className="h-6 text-xs"
                      disabled={newNote.tags.includes(tag)}
                    >
                      {tag}
                    </Button>
                  ))}
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {newNote.tags.map(tag => (
                    <Badge key={tag} className="cursor-pointer" onClick={() => handleRemoveTag(tag)}>
                      {tag} ×
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="pinned"
                  checked={newNote.pinned}
                  onChange={(e) => setNewNote(prev => ({ ...prev, pinned: e.target.checked }))}
                  className="w-4 h-4"
                />
                <label htmlFor="pinned" className="text-sm">Pin this note</label>
              </div>
              
              <Button 
                onClick={handleAddNote}
                className="w-full bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                {editingNote ? 'Update Note' : 'Save Note'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search notes..."
                className="pl-10"
              />
            </div>
            <Tabs value={activeFilter} onValueChange={(value: any) => setActiveFilter(value)}>
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="pinned">Pinned</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>

      {/* Quick Note Input */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg handwritten">Quick Note</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Textarea
              value={quickNote}
              onChange={(e) => setQuickNote(e.target.value)}
              placeholder="Jot down your thoughts..."
              className="handwritten resize-none"
              rows={3}
            />
            <div className="flex justify-between items-center">
              <div className="flex space-x-2">
                {predefinedTags.slice(0, 3).map(tag => (
                  <Button
                    key={tag}
                    variant="outline"
                    size="sm"
                    className="h-6 text-xs"
                    onClick={() => setQuickNote(prev => prev + ` #${tag}`)}
                  >
                    #{tag}
                  </Button>
                ))}
              </div>
              <Button onClick={handleQuickSave} className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
                Save Note
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note) => (
          <Card key={note.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  {note.pinned && <Pin className="h-4 w-4 text-[var(--journal-blue)]" />}
                  {note.pinned && <span className="text-xs text-slate-500">Pinned</span>}
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleTogglePin(note.id)}
                    className="text-slate-400 hover:text-[var(--journal-blue)]"
                  >
                    <Pin className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEditNote(note)}
                    className="text-slate-400 hover:text-[var(--journal-blue)]"
                  >
                    <Edit3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteNote(note.id)}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              {note.title && (
                <h3 className="font-medium text-slate-800 handwritten mb-2">{note.title}</h3>
              )}
              
              <div className="handwritten text-slate-700 mb-4 line-clamp-4">
                {note.content}
              </div>
              
              <div className="flex items-center justify-between text-xs text-slate-500">
                <div className="flex flex-wrap gap-1">
                  {note.tags.slice(0, 2).map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {note.tags.length > 2 && (
                    <Badge variant="secondary" className="text-xs">
                      +{note.tags.length - 2}
                    </Badge>
                  )}
                </div>
                <span>{format(new Date(note.createdAt), 'MMM dd')}</span>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Protected Sections Cards */}
        <Card 
          className="bg-gradient-to-br from-[var(--journal-blue)] to-[var(--journal-dark)] text-white cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => onProtectedAccess('journal')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold handwritten">Private Journal</h3>
              <Lock className="h-5 w-5" />
            </div>
            <p className="text-sm opacity-90 mb-4">Access your personal thoughts and reflections in a secure space.</p>
            <Button 
              variant="secondary" 
              size="sm"
              className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 text-white border-0"
            >
              <Lock className="h-4 w-4 mr-2" />
              Unlock
            </Button>
          </CardContent>
        </Card>

        <Card 
          className="bg-gradient-to-br from-green-500 to-green-600 text-white cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => onProtectedAccess('aichat')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold handwritten">Prayer & Stotra</h3>
              <BookOpen className="h-5 w-5" />
            </div>
            <p className="text-sm opacity-90 mb-4">Store your personal prayers and spiritual content safely.</p>
            <Button 
              variant="secondary" 
              size="sm"
              className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 text-white border-0"
            >
              <BookOpen className="h-4 w-4 mr-2" />
              View Collection
            </Button>
          </CardContent>
        </Card>
      </div>

      {filteredNotes.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-slate-500">No notes found. Start by creating your first note!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
