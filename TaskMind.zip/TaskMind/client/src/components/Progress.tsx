import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Clock, 
  CheckSquare, 
  Flame, 
  Percent,
  TrendingUp,
  Star,
  Calendar,
  BookOpen,
  Lightbulb,
  Target
} from "lucide-react";
import { StatsStorage, TaskStorage, SubjectStorage, TimerStorage } from "@/lib/storage";
import { StudyStats, Task, Subject } from "@/types";
import { format, subDays, startOfWeek, eachDayOfInterval } from "date-fns";

export default function Progress() {
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [weeklyData, setWeeklyData] = useState<{ day: string; hours: number; tasks: number }[]>([]);

  useEffect(() => {
    // Load data
    setStats(StatsStorage.getStats());
    setTasks(TaskStorage.getTasks());
    setSubjects(SubjectStorage.getSubjects());
    
    // Generate weekly data for chart
    const startOfCurrentWeek = startOfWeek(new Date());
    const weekDays = eachDayOfInterval({
      start: startOfCurrentWeek,
      end: new Date()
    });

    const weeklyChartData = weekDays.map(day => ({
      day: format(day, 'EEE'),
      hours: Math.floor(Math.random() * 8) + 1, // Simulated data - in real app would come from daily tracking
      tasks: Math.floor(Math.random() * 5) + 1
    }));

    setWeeklyData(weeklyChartData);
  }, []);

  const completedTasks = tasks.filter(task => task.completed);
  const overdueTasks = tasks.filter(task => {
    if (!task.deadline || task.completed) return false;
    return new Date(task.deadline) < new Date();
  });

  const getSubjectProgressData = () => {
    return subjects.map(subject => ({
      name: subject.name,
      progress: subject.totalChapters > 0 ? (subject.completedChapters / subject.totalChapters) * 100 : 0,
      color: subject.color,
      completed: subject.completedChapters,
      total: subject.totalChapters
    }));
  };

  const getProductivityInsights = () => {
    const insights = [];
    
    if (stats) {
      // Peak productivity time
      insights.push({
        icon: Star,
        text: "You're most productive between 7-9 PM",
        color: "text-yellow-500"
      });

      // Best study day
      const bestDay = weeklyData.reduce((prev, current) => 
        (prev.hours > current.hours) ? prev : current
      );
      insights.push({
        icon: Calendar,
        text: `${bestDay.day}s are your best study days`,
        color: "text-blue-500"
      });

      // Subject performance
      const scienceSubjects = subjects.filter(s => 
        ['Physics', 'Chemistry', 'Mathematics', 'Biology'].includes(s.name)
      );
      if (scienceSubjects.length > 0) {
        insights.push({
          icon: BookOpen,
          text: "Science subjects performed best after 6 PM",
          color: "text-green-500"
        });
      }

      // Focus session average
      const timerState = TimerStorage.getState();
      const avgFocusTime = Math.floor(25 - (timerState.timeLeft / 60));
      insights.push({
        icon: Target,
        text: `Average focus session: ${avgFocusTime} minutes`,
        color: "text-purple-500"
      });
    }

    return insights;
  };

  const getRecommendations = () => [
    {
      text: "Consider scheduling important topics during your peak hours (7-9 PM)",
      color: "bg-blue-50 text-blue-800"
    },
    {
      text: "Try to maintain your Wednesday study routine throughout the week",
      color: "bg-green-50 text-green-800"
    },
    {
      text: "Gradually increase your focus sessions to 25-30 minutes",
      color: "bg-yellow-50 text-yellow-800"
    }
  ];

  if (!stats) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-slate-500">Loading progress data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800 handwritten">Progress & Analytics</h2>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Clock className="h-8 w-8 text-[var(--journal-blue)] mx-auto mb-3" />
            <div className="text-2xl font-bold text-slate-800 handwritten">
              {Math.floor(stats.totalStudyTime / 60)}
            </div>
            <div className="text-sm text-slate-600">Study Hours This Month</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <CheckSquare className="h-8 w-8 text-green-500 mx-auto mb-3" />
            <div className="text-2xl font-bold text-slate-800 handwritten">
              {stats.tasksCompleted}
            </div>
            <div className="text-sm text-slate-600">Tasks Completed</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <Flame className="h-8 w-8 text-red-500 mx-auto mb-3" />
            <div className="text-2xl font-bold text-slate-800 handwritten">
              {stats.currentStreak}
            </div>
            <div className="text-sm text-slate-600">Day Streak</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 text-center">
            <Percent className="h-8 w-8 text-purple-500 mx-auto mb-3" />
            <div className="text-2xl font-bold text-slate-800 handwritten">
              {subjects.length > 0 
                ? Math.round(subjects.reduce((sum, s) => sum + (s.completedChapters / s.totalChapters * 100), 0) / subjects.length)
                : 0}%
            </div>
            <div className="text-sm text-slate-600">Overall Progress</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Study Hours Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="handwritten">Daily Study Hours</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-end justify-between space-x-2">
              {weeklyData.map((day, index) => (
                <div key={index} className="flex flex-col items-center space-y-2 flex-1">
                  <div 
                    className="w-full bg-[var(--journal-blue)] rounded-t transition-all duration-300 hover:opacity-80"
                    style={{ height: `${(day.hours / 8) * 200}px`, minHeight: '20px' }}
                  />
                  <span className="text-xs text-slate-500">{day.day}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 text-center text-sm text-slate-600">
              Weekly average: {Math.round(weeklyData.reduce((sum, day) => sum + day.hours, 0) / weeklyData.length)} hours/day
            </div>
          </CardContent>
        </Card>

        {/* Subject Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="handwritten">Subject-wise Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {getSubjectProgressData().map((subject, index) => (
                <div key={index}>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium">{subject.name}</span>
                    <span className="text-slate-600">
                      {subject.completed}/{subject.total} ({Math.round(subject.progress)}%)
                    </span>
                  </div>
                  <ProgressBar value={subject.progress} className="h-2" />
                </div>
              ))}
              
              {subjects.length === 0 && (
                <div className="text-center py-8 text-slate-500">
                  <BookOpen className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No subjects added yet. Add subjects in the Syllabus section to track progress.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tasks Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="handwritten">Task Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-slate-800 handwritten mb-2">{tasks.length}</div>
              <div className="text-sm text-slate-600 mb-4">Total Tasks</div>
              <ProgressBar value={tasks.length > 0 ? (completedTasks.length / tasks.length) * 100 : 0} />
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-green-500 handwritten mb-2">{completedTasks.length}</div>
              <div className="text-sm text-slate-600 mb-4">Completed</div>
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                {tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0}% completion rate
              </Badge>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-red-500 handwritten mb-2">{overdueTasks.length}</div>
              <div className="text-sm text-slate-600 mb-4">Overdue</div>
              {overdueTasks.length > 0 ? (
                <Badge variant="destructive">Needs attention</Badge>
              ) : (
                <Badge className="bg-green-100 text-green-800">All caught up!</Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weekly Pattern Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="handwritten">Weekly Pattern Analysis</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-medium text-slate-700 flex items-center">
                <TrendingUp className="h-5 w-5 mr-2 text-[var(--journal-blue)]" />
                Productivity Insights
              </h4>
              <div className="space-y-3">
                {getProductivityInsights().map((insight, index) => {
                  const Icon = insight.icon;
                  return (
                    <div key={index} className="flex items-center space-x-3">
                      <Icon className={`h-4 w-4 ${insight.color}`} />
                      <span className="text-sm text-slate-600">{insight.text}</span>
                    </div>
                  );
                })}
              </div>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-medium text-slate-700 flex items-center">
                <Lightbulb className="h-5 w-5 mr-2 text-yellow-500" />
                Recommendations
              </h4>
              <div className="space-y-3">
                {getRecommendations().map((rec, index) => (
                  <div key={index} className={`p-3 rounded-lg ${rec.color}`}>
                    <p className="text-sm">{rec.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Study Streak & Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="handwritten">Study Streak</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="mb-4">
              <Flame className="h-16 w-16 text-red-500 mx-auto mb-2" />
              <div className="text-4xl font-bold text-slate-800 handwritten">{stats.currentStreak}</div>
              <div className="text-sm text-slate-600">Current Streak</div>
            </div>
            <div className="text-sm text-slate-500">
              Longest streak: {stats.longestStreak} days
            </div>
            <ProgressBar 
              value={stats.longestStreak > 0 ? (stats.currentStreak / stats.longestStreak) * 100 : 0} 
              className="mt-3" 
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="handwritten">Monthly Goals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Study Hours</span>
                  <span>{Math.floor(stats.totalStudyTime / 60)}/120</span>
                </div>
                <ProgressBar value={(stats.totalStudyTime / 60 / 120) * 100} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Tasks Completed</span>
                  <span>{stats.tasksCompleted}/100</span>
                </div>
                <ProgressBar value={(stats.tasksCompleted / 100) * 100} />
              </div>
              
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Consistency</span>
                  <span>{stats.currentStreak}/30 days</span>
                </div>
                <ProgressBar value={(stats.currentStreak / 30) * 100} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
