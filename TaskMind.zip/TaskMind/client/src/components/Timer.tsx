import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Play, Pause, Square, Settings } from "lucide-react";
import { TimerStorage, StatsStorage } from "@/lib/storage";
import { TimerState, TimerSettings, StudyStats } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function Timer() {
  const { toast } = useToast();
  const [timerState, setTimerState] = useState<TimerState>(() => TimerStorage.getState());
  const [settings, setSettings] = useState<TimerSettings>(() => TimerStorage.getSettings());
  const [showSettings, setShowSettings] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (timerState.isRunning) {
      intervalRef.current = setInterval(() => {
        setTimerState(prev => {
          if (prev.timeLeft <= 1) {
            handleSessionComplete();
            return prev;
          }
          const newState = { ...prev, timeLeft: prev.timeLeft - 1 };
          TimerStorage.saveState(newState);
          return newState;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timerState.isRunning]);

  const handleSessionComplete = () => {
    // Show notification
    if (settings.notifications && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        new Notification('Pomodoro Timer', {
          body: timerState.currentSession === 'focus' 
            ? 'Focus session complete! Time for a break.' 
            : 'Break time over! Ready for another focus session?',
          icon: '/favicon.ico'
        });
      }
    }

    // Update stats
    if (timerState.currentSession === 'focus') {
      const stats = StatsStorage.getStats();
      const newStats: StudyStats = {
        ...stats,
        totalStudyTime: stats.totalStudyTime + settings.focusDuration,
      };
      StatsStorage.saveStats(newStats);
    }

    // Determine next session
    const isLongBreakTime = (timerState.sessionsCompleted + 1) % settings.longBreakInterval === 0;
    let nextSession: 'focus' | 'shortBreak' | 'longBreak';
    let nextDuration: number;

    if (timerState.currentSession === 'focus') {
      nextSession = isLongBreakTime ? 'longBreak' : 'shortBreak';
      nextDuration = isLongBreakTime ? settings.longBreak : settings.shortBreak;
    } else {
      nextSession = 'focus';
      nextDuration = settings.focusDuration;
    }

    const newState: TimerState = {
      timeLeft: nextDuration * 60,
      isRunning: timerState.currentSession === 'focus' 
        ? settings.autoStartBreaks 
        : settings.autoStartPomodoros,
      currentSession: nextSession,
      sessionsCompleted: timerState.currentSession === 'focus' 
        ? timerState.sessionsCompleted + 1 
        : timerState.sessionsCompleted,
      totalSessionsToday: timerState.currentSession === 'focus'
        ? timerState.totalSessionsToday + 1
        : timerState.totalSessionsToday,
    };

    setTimerState(newState);
    TimerStorage.saveState(newState);

    toast({
      title: timerState.currentSession === 'focus' ? "Focus session complete!" : "Break time over!",
      description: nextSession === 'focus' 
        ? "Ready for another focus session?" 
        : `Time for a ${nextSession === 'longBreak' ? 'long' : 'short'} break.`,
    });
  };

  const handleStart = () => {
    // Request notification permission
    if (settings.notifications && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    const newState = { ...timerState, isRunning: true };
    setTimerState(newState);
    TimerStorage.saveState(newState);
  };

  const handlePause = () => {
    const newState = { ...timerState, isRunning: false };
    setTimerState(newState);
    TimerStorage.saveState(newState);
  };

  const handleReset = () => {
    const duration = timerState.currentSession === 'focus' 
      ? settings.focusDuration 
      : timerState.currentSession === 'shortBreak' 
        ? settings.shortBreak 
        : settings.longBreak;

    const newState: TimerState = {
      ...timerState,
      timeLeft: duration * 60,
      isRunning: false,
    };
    setTimerState(newState);
    TimerStorage.saveState(newState);
  };

  const updateSettings = (newSettings: Partial<TimerSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    TimerStorage.saveSettings(updated);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = () => {
    const totalTime = timerState.currentSession === 'focus' 
      ? settings.focusDuration * 60
      : timerState.currentSession === 'shortBreak' 
        ? settings.shortBreak * 60
        : settings.longBreak * 60;
    return ((totalTime - timerState.timeLeft) / totalTime) * 100;
  };

  const getSessionLabel = () => {
    switch (timerState.currentSession) {
      case 'focus': return 'Focus Session';
      case 'shortBreak': return 'Short Break';
      case 'longBreak': return 'Long Break';
    }
  };

  const getSessionColor = () => {
    switch (timerState.currentSession) {
      case 'focus': return 'var(--journal-blue)';
      case 'shortBreak': return '#10B981';
      case 'longBreak': return '#8B5CF6';
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800 handwritten">Pomodoro Timer</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowSettings(!showSettings)}
        >
          <Settings className="h-4 w-4 mr-2" />
          Settings
        </Button>
      </div>

      {/* Timer Display */}
      <Card className="text-center">
        <CardContent className="p-8">
          <div className="relative w-48 h-48 mx-auto mb-8">
            <svg className="w-48 h-48" viewBox="0 0 36 36">
              <path
                d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#E5E7EB"
                strokeWidth="1"
              />
              <path
                className="timer-circle"
                d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke={getSessionColor()}
                strokeWidth="1"
                strokeDasharray={`${getProgress()}, 100`}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <div className="text-4xl font-bold text-slate-800 handwritten mb-2">
                {formatTime(timerState.timeLeft)}
              </div>
              <Badge variant="secondary" className="text-sm">
                {getSessionLabel()}
              </Badge>
            </div>
          </div>

          {/* Timer Controls */}
          <div className="flex justify-center space-x-4 mb-6">
            {!timerState.isRunning ? (
              <Button onClick={handleStart} className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
                <Play className="h-4 w-4 mr-2" />
                Start
              </Button>
            ) : (
              <Button onClick={handlePause} variant="secondary">
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </Button>
            )}
            <Button onClick={handleReset} variant="destructive">
              <Square className="h-4 w-4 mr-2" />
              Reset
            </Button>
          </div>

          {/* Session Info */}
          <Card className="bg-[var(--journal-light)]">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-semibold text-[var(--journal-blue)]">Sessions Today</div>
                  <div className="text-lg handwritten">{timerState.totalSessionsToday}</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-[var(--journal-blue)]">Completed</div>
                  <div className="text-lg handwritten">{timerState.sessionsCompleted}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>

      {/* Timer Settings */}
      {showSettings && (
        <Card>
          <CardHeader>
            <CardTitle className="handwritten">Timer Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Focus Duration (minutes)</Label>
                <Select
                  value={settings.focusDuration.toString()}
                  onValueChange={(value) => updateSettings({ focusDuration: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="20">20 minutes</SelectItem>
                    <SelectItem value="25">25 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                    <SelectItem value="50">50 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Short Break (minutes)</Label>
                <Select
                  value={settings.shortBreak.toString()}
                  onValueChange={(value) => updateSettings({ shortBreak: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 minutes</SelectItem>
                    <SelectItem value="5">5 minutes</SelectItem>
                    <SelectItem value="10">10 minutes</SelectItem>
                    <SelectItem value="15">15 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Long Break (minutes)</Label>
                <Select
                  value={settings.longBreak.toString()}
                  onValueChange={(value) => updateSettings({ longBreak: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 minutes</SelectItem>
                    <SelectItem value="20">20 minutes</SelectItem>
                    <SelectItem value="25">25 minutes</SelectItem>
                    <SelectItem value="30">30 minutes</SelectItem>
                    <SelectItem value="45">45 minutes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Switch
                  id="notifications"
                  checked={settings.notifications}
                  onCheckedChange={(checked) => updateSettings({ notifications: checked })}
                />
                <Label htmlFor="notifications">Enable browser notifications</Label>
              </div>

              <div className="flex items-center space-x-3">
                <Switch
                  id="autoStartBreaks"
                  checked={settings.autoStartBreaks}
                  onCheckedChange={(checked) => updateSettings({ autoStartBreaks: checked })}
                />
                <Label htmlFor="autoStartBreaks">Auto-start breaks</Label>
              </div>

              <div className="flex items-center space-x-3">
                <Switch
                  id="autoStartPomodoros"
                  checked={settings.autoStartPomodoros}
                  onCheckedChange={(checked) => updateSettings({ autoStartPomodoros: checked })}
                />
                <Label htmlFor="autoStartPomodoros">Auto-start focus sessions</Label>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
