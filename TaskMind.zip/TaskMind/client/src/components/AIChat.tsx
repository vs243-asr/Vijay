import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Send, Bot, User, Settings, Heart, Brain, Plus, Trash2, MessageCircle } from "lucide-react";
import { AIBhaiya, ChatMessage } from "@/lib/openai";
import { useLocalStorage } from "@/hooks/useLocalStorage";
import { useToast } from "@/hooks/use-toast";

interface AIChatProps {
  password: string;
}

interface ChatSession {
  id: string;
  messages: ChatMessage[];
  timestamp: string;
}

export default function AIChat({ password }: AIChatProps) {
  const { toast } = useToast();
  const [aiInstance] = useState(() => new AIBhaiya());
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isEnabled, setIsEnabled] = useLocalStorage('ai_chat_enabled', false);
  const [memories, setMemories] = useLocalStorage<string[]>('ai_memories', []);
  const [newMemory, setNewMemory] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [mode, setMode] = useState<'talk' | 'listen'>('talk');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize AI with memories
    if (memories.length > 0) {
      aiInstance.setMemory(memories);
    }
  }, [memories, aiInstance]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isLoading || !isEnabled) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: inputMessage.trim()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await aiInstance.chat(inputMessage.trim());
      
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      toast({
        title: "Message sent",
        description: "Your AI bhaiya has responded",
      });
    } catch (error) {
      console.error('Chat error:', error);
      
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: "Hey, I'm having some trouble right now. But remember - I believe in you! Keep pushing towards your goals. We can chat more when things are working better."
      };

      setMessages(prev => [...prev, errorMessage]);
      
      toast({
        title: "Connection issue",
        description: "AI chat is temporarily unavailable",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddMemory = () => {
    if (!newMemory.trim()) return;
    
    const updatedMemories = [...memories, newMemory.trim()];
    setMemories(updatedMemories);
    aiInstance.addMemory(newMemory.trim());
    setNewMemory('');
    
    toast({
      title: "Memory added",
      description: "Your AI bhaiya will remember this",
    });
  };

  const handleRemoveMemory = (index: number) => {
    const updatedMemories = memories.filter((_, i) => i !== index);
    setMemories(updatedMemories);
    aiInstance.setMemory(updatedMemories);
    
    toast({
      title: "Memory removed",
      description: "This information has been forgotten",
    });
  };

  const clearConversation = () => {
    setMessages([]);
    aiInstance.clearConversation();
    
    toast({
      title: "Conversation cleared",
      description: "Starting fresh with your AI bhaiya",
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isEnabled) {
    return (
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Bot className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-xl handwritten">AI Bhaiya Chat</CardTitle>
            <p className="text-slate-600">
              Your supportive AI companion is here to help with studies, motivation, and guidance.
            </p>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
              <Heart className="h-12 w-12 text-red-500 mx-auto mb-4" />
              <h3 className="font-semibold text-slate-800 mb-2">Your Caring AI Bhaiya</h3>
              <p className="text-sm text-slate-600 mb-4">
                Like a loving older brother, I'm here to support your academic journey, 
                provide motivation, and help you achieve your goals of AIR 1 in CLAT and UPSC.
              </p>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>• Personalized study guidance</li>
                <li>• Motivational support when you need it</li>
                <li>• Help with academic planning</li>
                <li>• Emotional support during tough times</li>
              </ul>
            </div>
            
            <div className="flex items-center justify-center space-x-3">
              <Switch
                id="enable-ai"
                checked={isEnabled}
                onCheckedChange={setIsEnabled}
              />
              <Label htmlFor="enable-ai" className="font-medium">
                Enable AI Bhaiya Chat
              </Label>
            </div>
            
            <p className="text-xs text-slate-500">
              Note: This feature requires an OpenAI API key. Your conversations are private and not stored on any server.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 handwritten">AI Bhaiya Chat</h2>
          <p className="text-slate-600 text-sm">Your supportive AI companion</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant={mode === 'talk' ? 'default' : 'secondary'}>
            {mode === 'talk' ? 'Talk Mode' : 'Listen Mode'}
          </Badge>
          <Dialog open={showSettings} onOpenChange={setShowSettings}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="handwritten">AI Bhaiya Settings</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="enable-chat">Enable Chat</Label>
                  <Switch
                    id="enable-chat"
                    checked={isEnabled}
                    onCheckedChange={setIsEnabled}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Chat Mode</Label>
                  <div className="flex space-x-2">
                    <Button
                      variant={mode === 'talk' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setMode('talk')}
                      className="flex-1"
                    >
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Talk
                    </Button>
                    <Button
                      variant={mode === 'listen' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setMode('listen')}
                      className="flex-1"
                    >
                      <Brain className="h-4 w-4 mr-2" />
                      Listen
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Memory Management</Label>
                  <div className="flex space-x-2">
                    <Input
                      value={newMemory}
                      onChange={(e) => setNewMemory(e.target.value)}
                      placeholder="Add something for me to remember..."
                      className="flex-1"
                    />
                    <Button onClick={handleAddMemory} size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="max-h-32 overflow-y-auto space-y-1">
                    {memories.map((memory, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded text-sm">
                        <span className="flex-1 truncate">{memory}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveMemory(index)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Button onClick={clearConversation} variant="outline" className="w-full">
                  Clear Conversation
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Chat Interface */}
      <Card className="h-96">
        <CardHeader className="pb-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold handwritten">Your AI Bhaiya</h3>
              <p className="text-xs text-slate-500">
                Here to support your journey to AIR 1 🎯
              </p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="h-64 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 && (
              <div className="text-center py-8">
                <Heart className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <p className="text-slate-600 handwritten">
                  Hey there! I'm your AI bhaiya, ready to support you on your journey. 
                  How can I help you today?
                </p>
              </div>
            )}
            
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-[var(--journal-blue)] text-white'
                      : 'bg-slate-100 text-slate-800'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    {message.role === 'user' ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                    <span className="text-xs font-medium">
                      {message.role === 'user' ? 'You' : 'AI Bhaiya'}
                    </span>
                  </div>
                  <p className={`text-sm leading-relaxed ${message.role === 'assistant' ? 'handwritten' : ''}`}>
                    {message.content}
                  </p>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-100 rounded-lg px-4 py-2">
                  <div className="flex items-center space-x-2">
                    <Bot className="h-4 w-4" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
          
          {/* Input Area */}
          <div className="border-t p-4">
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder={mode === 'listen' ? "I'm listening... share what's on your mind" : "Ask me anything about studies, motivation, or life..."}
                className="flex-1 handwritten"
                disabled={isLoading}
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || isLoading}
                className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-slate-500 mt-2">
              Press Enter to send • Shift+Enter for new line
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2"
          onClick={() => setInputMessage("I need some motivation to study today")}
        >
          <Heart className="h-5 w-5 text-red-500" />
          <span className="text-sm">Need Motivation</span>
        </Button>
        
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2"
          onClick={() => setInputMessage("Help me plan my study schedule for today")}
        >
          <Brain className="h-5 w-5 text-purple-500" />
          <span className="text-sm">Study Planning</span>
        </Button>
        
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2"
          onClick={() => setInputMessage("I'm feeling overwhelmed with my preparation")}
        >
          <MessageCircle className="h-5 w-5 text-blue-500" />
          <span className="text-sm">Need Support</span>
        </Button>
      </div>

      {/* Privacy Notice */}
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <Bot className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <h4 className="font-medium text-slate-800 text-sm">Privacy Protected</h4>
              <p className="text-xs text-slate-600">
                Your conversations are private and not stored on any server. All data stays in your browser.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
