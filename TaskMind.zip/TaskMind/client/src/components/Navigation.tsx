import { TabType } from "@/App";
import { Button } from "@/components/ui/button";
import { 
  Home, 
  Clock, 
  CheckSquare, 
  Book, 
  StickyNote, 
  TrendingUp, 
  Target 
} from "lucide-react";

interface NavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

const navigationItems = [
  { id: 'dashboard' as TabType, label: 'Dashboard', icon: Home },
  { id: 'timer' as TabType, label: 'Timer', icon: Clock },
  { id: 'tasks' as TabType, label: 'Tasks', icon: CheckSquare },
  { id: 'syllabus' as TabType, label: 'Syllabus', icon: Book },
  { id: 'notes' as TabType, label: 'Notes', icon: StickyNote },
  { id: 'progress' as TabType, label: 'Progress', icon: TrendingUp },
];

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  return (
    <>
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200 px-4 py-3 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[var(--journal-blue)] rounded-full flex items-center justify-center">
              <Target className="h-4 w-4 text-white" />
            </div>
            <h1 className="text-xl font-bold text-[var(--journal-blue)] handwritten">Lakshya</h1>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              return (
                <Button
                  key={item.id}
                  variant={activeTab === item.id ? "default" : "ghost"}
                  className={`px-3 py-2 rounded-lg transition-colors ${
                    activeTab === item.id 
                      ? "bg-[var(--journal-blue)] text-white" 
                      : "text-slate-600 hover:text-[var(--journal-blue)] hover:bg-slate-100"
                  }`}
                  onClick={() => onTabChange(item.id)}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {item.label}
                </Button>
              );
            })}
          </nav>
          
          {/* Mobile menu button */}
          <Button variant="ghost" size="sm" className="md:hidden text-[var(--journal-blue)]">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </Button>
        </div>
      </header>

      {/* Mobile Navigation */}
      <nav className="md:hidden bg-white border-b border-slate-200 px-4 py-2">
        <div className="flex space-x-4 overflow-x-auto">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={activeTab === item.id ? "default" : "ghost"}
                size="sm"
                className={`px-3 py-2 rounded-lg whitespace-nowrap transition-colors ${
                  activeTab === item.id 
                    ? "bg-[var(--journal-blue)] text-white" 
                    : "text-slate-600 hover:text-[var(--journal-blue)] hover:bg-slate-100"
                }`}
                onClick={() => onTabChange(item.id)}
              >
                <Icon className="w-4 h-4 mr-1" />
                {item.label}
              </Button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
