import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit3, Trash2, BookOpen, Heart, Globe, Search, Copy, Check } from "lucide-react";
import { PrayerStorage } from "@/lib/storage";
import { PrayerEntry } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function Prayer() {
  const { toast } = useToast();
  const [prayers, setPrayers] = useState<PrayerEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeLanguage, setActiveLanguage] = useState<string>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingPrayer, setEditingPrayer] = useState<PrayerEntry | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [newPrayer, setNewPrayer] = useState({
    title: '',
    content: '',
    language: '',
    category: '',
  });

  useEffect(() => {
    setPrayers(PrayerStorage.getPrayers());
  }, []);

  const languages = [
    { code: 'hindi', name: 'Hindi (हिंदी)' },
    { code: 'sanskrit', name: 'Sanskrit (संस्कृत)' },
    { code: 'english', name: 'English' },
    { code: 'gujarati', name: 'Gujarati (ગુજરાતી)' },
    { code: 'marathi', name: 'Marathi (मराठी)' },
    { code: 'bengali', name: 'Bengali (বাংলা)' },
    { code: 'tamil', name: 'Tamil (தமிழ்)' },
    { code: 'telugu', name: 'Telugu (తెలుగు)' },
    { code: 'punjabi', name: 'Punjabi (ਪੰਜਾਬੀ)' },
  ];

  const categories = [
    'Morning Prayers',
    'Evening Prayers',
    'Study Prayers',
    'Gratitude',
    'Mantras',
    'Stotras',
    'Shlokas',
    'Personal Prayers',
    'Festival Prayers',
    'Meditation',
  ];

  const filteredPrayers = prayers.filter(prayer => {
    const matchesSearch = !searchTerm || 
      prayer.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prayer.content.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCategory = activeCategory === 'all' || prayer.category === activeCategory;
    const matchesLanguage = activeLanguage === 'all' || prayer.language === activeLanguage;

    return matchesSearch && matchesCategory && matchesLanguage;
  });

  const handleAddPrayer = () => {
    if (!newPrayer.title.trim() || !newPrayer.content.trim()) {
      toast({
        title: "Error",
        description: "Please fill in both title and content",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingPrayer) {
        PrayerStorage.updatePrayer(editingPrayer.id, {
          title: newPrayer.title,
          content: newPrayer.content,
          language: newPrayer.language || 'english',
          category: newPrayer.category || 'Personal Prayers',
        });

        setPrayers(prev => prev.map(prayer => 
          prayer.id === editingPrayer.id 
            ? { ...prayer, ...newPrayer, language: newPrayer.language || 'english', category: newPrayer.category || 'Personal Prayers' }
            : prayer
        ));

        toast({
          title: "Prayer updated",
          description: "Your prayer has been updated",
        });
      } else {
        const prayer = PrayerStorage.addPrayer({
          title: newPrayer.title,
          content: newPrayer.content,
          language: newPrayer.language || 'english',
          category: newPrayer.category || 'Personal Prayers',
        });

        setPrayers(prev => [prayer, ...prev]);

        toast({
          title: "Prayer saved",
          description: "Your prayer has been saved",
        });
      }

      setEditingPrayer(null);
      setNewPrayer({ title: '', content: '', language: '', category: '' });
      setIsAddDialogOpen(false);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to save prayer. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEditPrayer = (prayer: PrayerEntry) => {
    setEditingPrayer(prayer);
    setNewPrayer({
      title: prayer.title,
      content: prayer.content,
      language: prayer.language,
      category: prayer.category,
    });
    setIsAddDialogOpen(true);
  };

  const handleDeletePrayer = (id: string) => {
    try {
      PrayerStorage.deletePrayer(id);
      setPrayers(prev => prev.filter(prayer => prayer.id !== id));
      toast({
        title: "Prayer deleted",
        description: "Your prayer has been removed",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to delete prayer",
        variant: "destructive",
      });
    }
  };

  const handleCopyPrayer = async (prayer: PrayerEntry) => {
    try {
      await navigator.clipboard.writeText(prayer.content);
      setCopiedId(prayer.id);
      setTimeout(() => setCopiedId(null), 2000);
      
      toast({
        title: "Copied to clipboard",
        description: "Prayer text has been copied",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive",
      });
    }
  };

  const getLanguageName = (code: string) => {
    const language = languages.find(lang => lang.code === code);
    return language ? language.name : code;
  };

  const getCategoryColor = (category: string) => {
    const colors: { [key: string]: string } = {
      'Morning Prayers': 'bg-yellow-100 text-yellow-800',
      'Evening Prayers': 'bg-purple-100 text-purple-800',
      'Study Prayers': 'bg-blue-100 text-blue-800',
      'Gratitude': 'bg-green-100 text-green-800',
      'Mantras': 'bg-red-100 text-red-800',
      'Stotras': 'bg-orange-100 text-orange-800',
      'Shlokas': 'bg-pink-100 text-pink-800',
      'Personal Prayers': 'bg-gray-100 text-gray-800',
      'Festival Prayers': 'bg-indigo-100 text-indigo-800',
      'Meditation': 'bg-teal-100 text-teal-800',
    };
    return colors[category] || 'bg-slate-100 text-slate-800';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 handwritten">Prayer & Stotra Collection</h2>
          <p className="text-slate-600 text-sm">Your personal spiritual content library</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
              <Plus className="h-4 w-4 mr-2" />
              Add Prayer
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="handwritten">
                {editingPrayer ? 'Edit Prayer' : 'Add New Prayer'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={newPrayer.title}
                  onChange={(e) => setNewPrayer(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter prayer title..."
                  className="handwritten"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="language">Language</Label>
                  <Select value={newPrayer.language} onValueChange={(value) => setNewPrayer(prev => ({ ...prev, language: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map(lang => (
                        <SelectItem key={lang.code} value={lang.code}>{lang.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={newPrayer.category} onValueChange={(value) => setNewPrayer(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="content">Prayer Content</Label>
                <Textarea
                  id="content"
                  value={newPrayer.content}
                  onChange={(e) => setNewPrayer(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Enter your prayer, mantra, or stotra text..."
                  className="handwritten min-h-40"
                  rows={8}
                />
              </div>
              
              <Button 
                onClick={handleAddPrayer}
                className="w-full bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                {editingPrayer ? 'Update Prayer' : 'Save Prayer'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search prayers, mantras, stotras..."
                className="pl-10"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium">Filter by Category</Label>
                <Select value={activeCategory} onValueChange={setActiveCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label className="text-sm font-medium">Filter by Language</Label>
                <Select value={activeLanguage} onValueChange={setActiveLanguage}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Languages</SelectItem>
                    {languages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>{lang.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Prayer Collection */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPrayers.map((prayer) => (
          <Card key={prayer.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg handwritten text-slate-800 mb-2">
                    {prayer.title}
                  </CardTitle>
                  <div className="flex flex-col space-y-2">
                    <Badge className={getCategoryColor(prayer.category)}>
                      {prayer.category}
                    </Badge>
                    <div className="flex items-center space-x-2 text-xs text-slate-500">
                      <Globe className="h-3 w-3" />
                      <span>{getLanguageName(prayer.language)}</span>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopyPrayer(prayer)}
                    className="text-slate-400 hover:text-[var(--journal-blue)]"
                  >
                    {copiedId === prayer.id ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEditPrayer(prayer)}
                    className="text-slate-400 hover:text-[var(--journal-blue)]"
                  >
                    <Edit3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeletePrayer(prayer.id)}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="handwritten text-slate-700 leading-relaxed whitespace-pre-wrap text-sm max-h-32 overflow-y-auto">
                {prayer.content}
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredPrayers.length === 0 && prayers.length > 0 && (
          <div className="col-span-full">
            <Card>
              <CardContent className="p-8 text-center">
                <Search className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600">No prayers found matching your search criteria.</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {prayers.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <BookOpen className="h-16 w-16 text-slate-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-slate-800 handwritten mb-2">
              Start Your Spiritual Collection
            </h3>
            <p className="text-slate-600 mb-6">
              Add your favorite prayers, mantras, stotras, and spiritual content. 
              Support multiple languages and organize by categories.
            </p>
            <Button 
              onClick={() => setIsAddDialogOpen(true)}
              className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add First Prayer
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Quick Access */}
      {prayers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="handwritten">Quick Access</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {categories.slice(0, 5).map(category => {
                const count = prayers.filter(p => p.category === category).length;
                return (
                  <Button
                    key={category}
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveCategory(category)}
                    className="h-auto p-3 flex flex-col items-center space-y-1"
                    disabled={count === 0}
                  >
                    <span className="text-xs font-medium">{category}</span>
                    <Badge variant="secondary" className="text-xs">
                      {count}
                    </Badge>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Privacy Notice */}
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <Heart className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <h4 className="font-medium text-slate-800 text-sm">Personal & Private</h4>
              <p className="text-xs text-slate-600">
                Your spiritual content is stored privately in your browser and never shared or uploaded anywhere.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
