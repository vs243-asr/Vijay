import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit3, Trash2, BookOpen, Heart, Smile, Meh, Frown, Calendar } from "lucide-react";
import { JournalStorage } from "@/lib/storage";
import { JournalEntry } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface JournalProps {
  password: string;
}

export default function Journal({ password }: JournalProps) {
  const { toast } = useToast();
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [newEntry, setNewEntry] = useState({
    title: '',
    content: '',
    date: new Date().toISOString().split('T')[0],
    mood: '',
  });

  useEffect(() => {
    loadEntries();
  }, [password]);

  const loadEntries = async () => {
    try {
      setIsLoading(true);
      const journalEntries = JournalStorage.getEntries(password);
      setEntries(journalEntries);
      setError('');
    } catch (err) {
      setError('Failed to load journal entries. Please check your password.');
      setEntries([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddEntry = () => {
    if (!newEntry.title.trim() || !newEntry.content.trim()) {
      toast({
        title: "Error",
        description: "Please fill in both title and content",
        variant: "destructive",
      });
      return;
    }

    try {
      if (editingEntry) {
        JournalStorage.updateEntry(editingEntry.id, {
          title: newEntry.title,
          content: newEntry.content,
          date: newEntry.date,
          mood: newEntry.mood,
        }, password);

        setEntries(prev => prev.map(entry => 
          entry.id === editingEntry.id 
            ? { ...entry, ...newEntry }
            : entry
        ));

        toast({
          title: "Entry updated",
          description: "Your journal entry has been updated",
        });
      } else {
        const entry = JournalStorage.addEntry({
          title: newEntry.title,
          content: newEntry.content,
          date: newEntry.date,
          mood: newEntry.mood,
        }, password);

        setEntries(prev => [entry, ...prev]);

        toast({
          title: "Entry saved",
          description: "Your journal entry has been saved securely",
        });
      }

      setEditingEntry(null);
      setNewEntry({ title: '', content: '', date: new Date().toISOString().split('T')[0], mood: '' });
      setIsAddDialogOpen(false);
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to save entry. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleEditEntry = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setNewEntry({
      title: entry.title,
      content: entry.content,
      date: entry.date,
      mood: entry.mood || '',
    });
    setIsAddDialogOpen(true);
  };

  const handleDeleteEntry = (id: string) => {
    try {
      JournalStorage.deleteEntry(id, password);
      setEntries(prev => prev.filter(entry => entry.id !== id));
      toast({
        title: "Entry deleted",
        description: "Your journal entry has been deleted",
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to delete entry",
        variant: "destructive",
      });
    }
  };

  const getMoodIcon = (mood: string) => {
    switch (mood) {
      case 'happy': return <Smile className="h-4 w-4 text-green-500" />;
      case 'neutral': return <Meh className="h-4 w-4 text-yellow-500" />;
      case 'sad': return <Frown className="h-4 w-4 text-red-500" />;
      case 'excited': return <Heart className="h-4 w-4 text-pink-500" />;
      default: return null;
    }
  };

  const getMoodLabel = (mood: string) => {
    switch (mood) {
      case 'happy': return 'Happy';
      case 'neutral': return 'Neutral';
      case 'sad': return 'Sad';
      case 'excited': return 'Excited';
      default: return '';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-[var(--journal-blue)] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-500">Loading your private journal...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <BookOpen className="h-16 w-16 text-slate-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-slate-800 mb-2">Access Denied</h3>
        <p className="text-slate-600">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 handwritten">Private Journal</h2>
          <p className="text-slate-600 text-sm">Your personal thoughts and reflections</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
              <Plus className="h-4 w-4 mr-2" />
              New Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="handwritten">
                {editingEntry ? 'Edit Journal Entry' : 'New Journal Entry'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Entry Title</Label>
                <Input
                  id="title"
                  value={newEntry.title}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="What's on your mind today?"
                  className="handwritten"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newEntry.date}
                    onChange={(e) => setNewEntry(prev => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                
                <div>
                  <Label htmlFor="mood">Mood (Optional)</Label>
                  <Select value={newEntry.mood} onValueChange={(value) => setNewEntry(prev => ({ ...prev, mood: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="How are you feeling?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="happy">😊 Happy</SelectItem>
                      <SelectItem value="excited">🥰 Excited</SelectItem>
                      <SelectItem value="neutral">😐 Neutral</SelectItem>
                      <SelectItem value="sad">😢 Sad</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="content">Content</Label>
                <Textarea
                  id="content"
                  value={newEntry.content}
                  onChange={(e) => setNewEntry(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Write your thoughts, experiences, reflections..."
                  className="handwritten min-h-40"
                  rows={8}
                />
              </div>
              
              <Button 
                onClick={handleAddEntry}
                className="w-full bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                {editingEntry ? 'Update Entry' : 'Save Entry'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Journal Entries */}
      <div className="space-y-6">
        {entries.map((entry) => (
          <Card key={entry.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg handwritten text-slate-800 mb-1">
                    {entry.title}
                  </CardTitle>
                  <div className="flex items-center space-x-4 text-sm text-slate-500">
                    <span className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {format(new Date(entry.date), 'MMMM dd, yyyy')}
                    </span>
                    {entry.mood && (
                      <span className="flex items-center">
                        {getMoodIcon(entry.mood)}
                        <span className="ml-1">{getMoodLabel(entry.mood)}</span>
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEditEntry(entry)}
                    className="text-slate-400 hover:text-[var(--journal-blue)]"
                  >
                    <Edit3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDeleteEntry(entry.id)}
                    className="text-slate-400 hover:text-red-500"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="handwritten text-slate-700 leading-relaxed whitespace-pre-wrap">
                {entry.content}
              </div>
            </CardContent>
          </Card>
        ))}

        {entries.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <BookOpen className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-800 handwritten mb-2">
                Your Journal Awaits
              </h3>
              <p className="text-slate-600 mb-6">
                Start writing your first journal entry. This is your private space for thoughts, reflections, and memories.
              </p>
              <Button 
                onClick={() => setIsAddDialogOpen(true)}
                className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                <Plus className="h-4 w-4 mr-2" />
                Write First Entry
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Privacy Notice */}
      <Card className="bg-slate-50 border-slate-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <BookOpen className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <h4 className="font-medium text-slate-800 text-sm">Privacy Protected</h4>
              <p className="text-xs text-slate-600">
                Your journal entries are encrypted and stored locally in your browser. They never leave your device.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
