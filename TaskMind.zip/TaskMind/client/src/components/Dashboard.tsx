import { useState, useEffect } from "react";
import { TabType } from "@/App";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, 
  CheckSquare, 
  TrendingUp, 
  Play, 
  Plus, 
  Lightbulb, 
  PieChart,
  Trophy,
  Quote
} from "lucide-react";
import { TaskStorage, TimerStorage, StatsStorage, AppSettingsStorage } from "@/lib/storage";
import { Task, TimerState, StudyStats } from "@/types";

interface DashboardProps {
  onNavigate: (tab: TabType) => void;
  onProtectedAccess: (type: 'journal' | 'aichat') => void;
}

export default function Dashboard({ onNavigate, onProtectedAccess }: DashboardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [timerState, setTimerState] = useState<TimerState | null>(null);
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [dailyQuote, setDailyQuote] = useState<string>("");

  useEffect(() => {
    // Load data
    setTasks(TaskStorage.getTasks());
    setTimerState(TimerStorage.getState());
    setStats(StatsStorage.getStats());
    setDailyQuote(AppSettingsStorage.getDailyQuote());
  }, []);

  const todaysTasks = tasks.filter(task => {
    if (!task.deadline) return false;
    const today = new Date().toDateString();
    const taskDate = new Date(task.deadline).toDateString();
    return taskDate === today;
  });

  const completedTodayTasks = todaysTasks.filter(task => task.completed);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getTimerProgress = () => {
    if (!timerState) return 0;
    const totalTime = 25 * 60; // Default 25 minutes
    return ((totalTime - timerState.timeLeft) / totalTime) * 100;
  };

  const longTermGoals = [
    { label: "Class X Score", value: "99%+", color: "bg-blue-100 text-blue-800" },
    { label: "All Subjects", value: "100/100", color: "bg-green-100 text-green-800" },
    { label: "CLAT Exam", value: "AIR 1", color: "bg-purple-100 text-purple-800" },
    { label: "UPSC Exam", value: "AIR 1", color: "bg-red-100 text-red-800" },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 handwritten mb-2">Good Morning! ✨</h2>
        <p className="text-slate-600">Let's make today productive and meaningful.</p>
      </div>

      {/* Daily Motivation Card */}
      <Card className="bg-gradient-to-r from-[var(--journal-blue)] to-[var(--journal-dark)] text-white border-0">
        <CardContent className="p-6">
          <div className="flex items-center mb-3">
            <Quote className="h-5 w-5 opacity-70 mr-3" />
            <h3 className="font-semibold handwritten">Daily Motivation</h3>
          </div>
          <p className="text-lg handwritten leading-relaxed">
            {dailyQuote}
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Timer Status Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium handwritten">Timer Status</CardTitle>
            <Clock className="h-4 w-4 text-[var(--journal-blue)]" />
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="relative w-20 h-20 mx-auto mb-3">
                <svg className="w-20 h-20" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#E5E7EB"
                    strokeWidth="2"
                  />
                  <path
                    className="timer-circle"
                    d="M18 2.0845a 15.9155 15.9155 0 0 1 0 31.831a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="var(--journal-blue)"
                    strokeWidth="2"
                    strokeDasharray={`${getTimerProgress()}, 100`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-semibold text-slate-700">
                    {timerState ? formatTime(timerState.timeLeft) : "25:00"}
                  </span>
                </div>
              </div>
              <p className="text-sm text-slate-600 mb-2">
                {timerState?.currentSession === 'focus' ? 'Focus Session' : 
                 timerState?.currentSession === 'shortBreak' ? 'Short Break' : 
                 'Long Break'}
              </p>
              <Button 
                size="sm" 
                onClick={() => onNavigate('timer')}
                className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                Go to Timer
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Today's Tasks */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium handwritten">Today's Tasks</CardTitle>
            <CheckSquare className="h-4 w-4 text-[var(--journal-blue)]" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {todaysTasks.slice(0, 3).map((task) => (
                <div key={task.id} className="flex items-center space-x-3">
                  <input 
                    type="checkbox" 
                    checked={task.completed}
                    className="w-4 h-4 text-[var(--journal-blue)] rounded"
                    readOnly
                  />
                  <span className={`text-sm ${task.completed ? 'text-slate-500 line-through' : 'text-slate-700'}`}>
                    {task.title}
                  </span>
                </div>
              ))}
              {todaysTasks.length === 0 && (
                <p className="text-sm text-slate-500">No tasks for today</p>
              )}
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100">
              <p className="text-xs text-slate-500">
                {completedTodayTasks.length} of {todaysTasks.length} tasks completed
              </p>
              <Progress 
                value={todaysTasks.length > 0 ? (completedTodayTasks.length / todaysTasks.length) * 100 : 0} 
                className="mt-2"
              />
            </div>
          </CardContent>
        </Card>

        {/* Weekly Progress */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium handwritten">This Week</CardTitle>
            <TrendingUp className="h-4 w-4 text-[var(--journal-blue)]" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-600">Study Hours</span>
                  <span className="font-semibold text-slate-800">
                    {stats ? Math.floor(stats.totalStudyTime / 60) : 0}/40
                  </span>
                </div>
                <Progress value={stats ? (stats.totalStudyTime / 60 / 40) * 100 : 0} />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-600">Tasks Done</span>
                  <span className="font-semibold text-slate-800">
                    {stats?.tasksCompleted || 0}/25
                  </span>
                </div>
                <Progress value={stats ? (stats.tasksCompleted / 25) * 100 : 0} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Long-term Goals Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-slate-800 handwritten flex items-center">
            <Trophy className="h-5 w-5 text-yellow-500 mr-3" />
            Long-term Goals
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {longTermGoals.map((goal, index) => (
              <div key={index} className="text-center p-4 bg-[var(--journal-light)] rounded-lg">
                <div className="text-2xl font-bold text-[var(--journal-blue)] handwritten">
                  {goal.value}
                </div>
                <p className="text-sm text-slate-600 mt-1">{goal.label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2 hover:shadow-md transition-all"
          onClick={() => onNavigate('tasks')}
        >
          <Plus className="h-5 w-5 text-[var(--journal-blue)]" />
          <span className="text-sm font-medium">Add Task</span>
        </Button>
        
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2 hover:shadow-md transition-all"
          onClick={() => onNavigate('timer')}
        >
          <Play className="h-5 w-5 text-green-500" />
          <span className="text-sm font-medium">Start Timer</span>
        </Button>
        
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2 hover:shadow-md transition-all"
          onClick={() => onNavigate('notes')}
        >
          <Lightbulb className="h-5 w-5 text-yellow-500" />
          <span className="text-sm font-medium">Quick Note</span>
        </Button>
        
        <Button
          variant="outline"
          className="h-20 flex flex-col items-center justify-center space-y-2 hover:shadow-md transition-all"
          onClick={() => onNavigate('progress')}
        >
          <PieChart className="h-5 w-5 text-purple-500" />
          <span className="text-sm font-medium">View Progress</span>
        </Button>
      </div>
    </div>
  );
}
