import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProtectedModalProps {
  isOpen: boolean;
  type: 'journal' | 'aichat' | null;
  onUnlock: (password: string) => void;
  onClose: () => void;
}

export default function ProtectedModal({ isOpen, type, onUnlock, onClose }: ProtectedModalProps) {
  const { toast } = useToast();
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleUnlock = async () => {
    if (!password.trim()) {
      setError('Please enter a password');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Simulate validation delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // For demo purposes, accept any non-empty password
      // In a real app, this would validate against stored encrypted password
      if (password.trim().length >= 3) {
        onUnlock(password);
        setPassword('');
        toast({
          title: "Access granted",
          description: `Welcome to your ${type === 'journal' ? 'private journal' : 'AI companion'}`,
        });
      } else {
        setError('Password must be at least 3 characters long');
      }
    } catch (err) {
      setError('Failed to unlock. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setPassword('');
    setError('');
    onClose();
  };

  const getModalContent = () => {
    switch (type) {
      case 'journal':
        return {
          title: 'Private Journal',
          description: 'Enter your password to access your personal thoughts and reflections',
          icon: '📖'
        };
      case 'aichat':
        return {
          title: 'AI Bhaiya Chat',
          description: 'Enter your password to chat with your supportive AI companion',
          icon: '🤗'
        };
      default:
        return {
          title: 'Protected Section',
          description: 'Enter your password to access this private area',
          icon: '🔒'
        };
    }
  };

  const content = getModalContent();

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="text-center mb-4">
            <div className="w-16 h-16 bg-[var(--journal-blue)] rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="h-8 w-8 text-white" />
            </div>
            <DialogTitle className="text-xl font-bold text-slate-800 handwritten">
              {content.title}
            </DialogTitle>
            <p className="text-slate-600 mt-2 text-sm">
              {content.description}
            </p>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError('');
              }}
              placeholder="Enter your password..."
              className="handwritten"
              onKeyPress={(e) => e.key === 'Enter' && handleUnlock()}
              disabled={isLoading}
            />
            {error && (
              <div className="flex items-center space-x-2 text-red-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}
          </div>
          
          <div className="flex space-x-3">
            <Button 
              variant="outline" 
              className="flex-1" 
              onClick={handleClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button 
              className="flex-1 bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]" 
              onClick={handleUnlock}
              disabled={isLoading || !password.trim()}
            >
              {isLoading ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Unlocking...</span>
                </div>
              ) : (
                <>
                  <Lock className="h-4 w-4 mr-2" />
                  Unlock
                </>
              )}
            </Button>
          </div>
          
          <div className="text-center">
            <p className="text-xs text-slate-500">
              Your data is stored securely in your browser and never leaves your device.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
