import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit3, Trash2, Calendar, Folder, CheckCircle2 } from "lucide-react";
import { TaskStorage, StatsStorage } from "@/lib/storage";
import { Task } from "@/types";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function Tasks() {
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeFilter, setActiveFilter] = useState<'all' | 'today' | 'upcoming' | 'completed'>('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [newTask, setNewTask] = useState<{
    title: string;
    subject: string;
    deadline: string;
    priority: 'low' | 'medium' | 'high';
  }>({
    title: '',
    subject: '',
    deadline: '',
    priority: 'medium',
  });

  useEffect(() => {
    setTasks(TaskStorage.getTasks());
  }, []);

  const subjects = [
    'Mathematics',
    'Physics', 
    'Chemistry',
    'English',
    'History',
    'Biology',
    'Geography',
    'Computer Science',
    'General'
  ];

  const filteredTasks = tasks.filter(task => {
    const today = new Date().toDateString();
    const taskDate = task.deadline ? new Date(task.deadline).toDateString() : null;
    
    switch (activeFilter) {
      case 'today':
        return taskDate === today && !task.completed;
      case 'upcoming':
        return taskDate && new Date(task.deadline!) > new Date() && !task.completed;
      case 'completed':
        return task.completed;
      default:
        return true;
    }
  });

  const handleAddTask = () => {
    if (!newTask.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a task title",
        variant: "destructive",
      });
      return;
    }

    const task = TaskStorage.addTask({
      title: newTask.title,
      subject: newTask.subject || 'General',
      deadline: newTask.deadline || undefined,
      completed: false,
      priority: newTask.priority,
    });

    setTasks(prev => [task, ...prev]);
    setNewTask({ title: '', subject: '', deadline: '', priority: 'medium' });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Task added",
      description: "Your task has been added successfully",
    });
  };

  const handleToggleTask = (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;

    const completed = !task.completed;
    TaskStorage.updateTask(id, { completed });
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed } : t));

    if (completed) {
      // Update stats
      const stats = StatsStorage.getStats();
      StatsStorage.updateStats({ tasksCompleted: stats.tasksCompleted + 1 });
      
      toast({
        title: "Task completed!",
        description: "Great job! Keep up the momentum.",
      });
    }
  };

  const handleDeleteTask = (id: string) => {
    TaskStorage.deleteTask(id);
    setTasks(prev => prev.filter(t => t.id !== id));
    toast({
      title: "Task deleted",
      description: "The task has been removed",
    });
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setNewTask({
      title: task.title,
      subject: task.subject,
      deadline: task.deadline || '',
      priority: task.priority,
    });
    setIsAddDialogOpen(true);
  };

  const handleUpdateTask = () => {
    if (!editingTask || !newTask.title.trim()) return;

    TaskStorage.updateTask(editingTask.id, {
      title: newTask.title,
      subject: newTask.subject || 'General',
      deadline: newTask.deadline || undefined,
      priority: newTask.priority,
    });

    setTasks(prev => prev.map(t => 
      t.id === editingTask.id 
        ? { 
            ...t, 
            title: newTask.title,
            subject: newTask.subject || 'General',
            deadline: newTask.deadline || undefined,
            priority: newTask.priority,
          }
        : t
    ));

    setEditingTask(null);
    setNewTask({ title: '', subject: '', deadline: '', priority: 'medium' });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Task updated",
      description: "Your changes have been saved",
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-600';
      case 'medium': return 'bg-blue-100 text-blue-600';
      case 'low': return 'bg-green-100 text-green-600';
      default: return 'bg-slate-100 text-slate-600';
    }
  };

  const taskStats = {
    total: tasks.length,
    completed: tasks.filter(t => t.completed).length,
    inProgress: tasks.filter(t => !t.completed).length,
    overdue: tasks.filter(t => {
      if (!t.deadline || t.completed) return false;
      return new Date(t.deadline) < new Date();
    }).length,
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800 handwritten">Tasks & To-Do</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
              <Plus className="h-4 w-4 mr-2" />
              Add Task
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="handwritten">
                {editingTask ? 'Edit Task' : 'Add New Task'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Task Title</Label>
                <Input
                  id="title"
                  value={newTask.title}
                  onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter task title..."
                  className="handwritten"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="subject">Subject/Category</Label>
                  <Select value={newTask.subject} onValueChange={(value) => setNewTask(prev => ({ ...prev, subject: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select subject" />
                    </SelectTrigger>
                    <SelectContent>
                      {subjects.map(subject => (
                        <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={newTask.priority} onValueChange={(value: any) => setNewTask(prev => ({ ...prev, priority: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="deadline">Deadline (Optional)</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={newTask.deadline}
                  onChange={(e) => setNewTask(prev => ({ ...prev, deadline: e.target.value }))}
                />
              </div>
              
              <Button 
                onClick={editingTask ? handleUpdateTask : handleAddTask}
                className="w-full bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                {editingTask ? 'Update Task' : 'Add Task'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Task Filters */}
      <Tabs value={activeFilter} onValueChange={(value: any) => setActiveFilter(value)}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All Tasks</TabsTrigger>
          <TabsTrigger value="today">Today</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value={activeFilter} className="space-y-4">
          {/* Tasks List */}
          <div className="space-y-4">
            {filteredTasks.map((task) => (
              <Card key={task.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => handleToggleTask(task.id)}
                      className="w-5 h-5"
                    />
                    <div className="flex-1">
                      <h4 className={`font-medium handwritten ${task.completed ? 'line-through text-slate-500' : 'text-slate-800'}`}>
                        {task.title}
                      </h4>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-slate-500">
                        <span className="flex items-center">
                          <Folder className="h-3 w-3 mr-1" />
                          {task.subject}
                        </span>
                        {task.deadline && (
                          <span className="flex items-center">
                            <Calendar className="h-3 w-3 mr-1" />
                            Due: {format(new Date(task.deadline), 'MMM dd, yyyy')}
                          </span>
                        )}
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                        {task.completed && (
                          <span className="flex items-center text-green-600">
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Completed
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditTask(task)}
                        className="text-slate-400 hover:text-[var(--journal-blue)]"
                      >
                        <Edit3 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteTask(task.id)}
                        className="text-slate-400 hover:text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredTasks.length === 0 && (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-slate-500">No tasks found for this filter.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Task Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="handwritten">Task Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-[var(--journal-blue)] handwritten">{taskStats.total}</div>
              <div className="text-sm text-slate-600">Total Tasks</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-500 handwritten">{taskStats.completed}</div>
              <div className="text-sm text-slate-600">Completed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-500 handwritten">{taskStats.inProgress}</div>
              <div className="text-sm text-slate-600">In Progress</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-500 handwritten">{taskStats.overdue}</div>
              <div className="text-sm text-slate-600">Overdue</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
