import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, CheckCircle2, Clock, Circle, Calculator, Atom, FlaskConical, BookOpen, Landmark, Eye } from "lucide-react";
import { SubjectStorage } from "@/lib/storage";
import { Subject, Chapter } from "@/types";
import { useToast } from "@/hooks/use-toast";

export default function Syllabus() {
  const { toast } = useToast();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [viewingSubject, setViewingSubject] = useState<Subject | null>(null);
  const [newSubject, setNewSubject] = useState({
    name: '',
    icon: 'BookOpen',
    color: 'blue-500',
    chapters: [] as string[],
  });
  const [newChapter, setNewChapter] = useState('');

  useEffect(() => {
    setSubjects(SubjectStorage.getSubjects());
  }, []);

  const iconMap: { [key: string]: any } = {
    Calculator,
    Atom,
    FlaskConical,
    BookOpen,
    Landmark,
    Eye,
  };

  const colorOptions = [
    { name: 'Blue', value: 'blue-500' },
    { name: 'Green', value: 'green-500' },
    { name: 'Purple', value: 'purple-500' },
    { name: 'Red', value: 'red-500' },
    { name: 'Yellow', value: 'yellow-600' },
    { name: 'Pink', value: 'pink-500' },
  ];

  const iconOptions = [
    { name: 'Calculator', value: 'Calculator' },
    { name: 'Atom', value: 'Atom' },
    { name: 'FlaskConical', value: 'FlaskConical' },
    { name: 'Book', value: 'BookOpen' },
    { name: 'Landmark', value: 'Landmark' },
    { name: 'Eye', value: 'Eye' },
  ];

  const handleAddSubject = () => {
    if (!newSubject.name.trim()) {
      toast({
        title: "Error",
        description: "Please enter a subject name",
        variant: "destructive",
      });
      return;
    }

    const chapters: Chapter[] = newSubject.chapters.map((name, index) => ({
      id: `${Date.now()}-${index}`,
      name,
      completed: false,
    }));

    const subject = SubjectStorage.addSubject({
      name: newSubject.name,
      icon: newSubject.icon,
      color: newSubject.color,
      chapters,
      totalChapters: chapters.length,
      completedChapters: 0,
    });

    setSubjects(prev => [...prev, subject]);
    setNewSubject({ name: '', icon: 'BookOpen', color: 'blue-500', chapters: [] });
    setIsAddDialogOpen(false);
    
    toast({
      title: "Subject added",
      description: "Your subject has been added successfully",
    });
  };

  const handleAddChapter = () => {
    if (!newChapter.trim()) return;
    setNewSubject(prev => ({
      ...prev,
      chapters: [...prev.chapters, newChapter.trim()]
    }));
    setNewChapter('');
  };

  const handleRemoveChapter = (index: number) => {
    setNewSubject(prev => ({
      ...prev,
      chapters: prev.chapters.filter((_, i) => i !== index)
    }));
  };

  const handleToggleChapter = (subjectId: string, chapterId: string) => {
    const subject = subjects.find(s => s.id === subjectId);
    if (!subject) return;

    const chapter = subject.chapters.find(c => c.id === chapterId);
    if (!chapter) return;

    const updatedChapters = subject.chapters.map(c =>
      c.id === chapterId ? { ...c, completed: !c.completed } : c
    );

    const completedCount = updatedChapters.filter(c => c.completed).length;

    const updatedSubject: Subject = {
      ...subject,
      chapters: updatedChapters,
      completedChapters: completedCount,
    };

    SubjectStorage.updateSubject(subjectId, {
      chapters: updatedChapters,
      completedChapters: completedCount,
    });

    setSubjects(prev => prev.map(s => s.id === subjectId ? updatedSubject : s));

    if (viewingSubject && viewingSubject.id === subjectId) {
      setViewingSubject(updatedSubject);
    }

    toast({
      title: chapter.completed ? "Chapter unchecked" : "Chapter completed!",
      description: `${chapter.name} has been ${chapter.completed ? 'unchecked' : 'marked as complete'}`,
    });
  };

  const getOverallProgress = () => {
    if (subjects.length === 0) return 0;
    const totalChapters = subjects.reduce((sum, s) => sum + s.totalChapters, 0);
    const completedChapters = subjects.reduce((sum, s) => sum + s.completedChapters, 0);
    return totalChapters > 0 ? (completedChapters / totalChapters) * 100 : 0;
  };

  const getSubjectProgress = (subject: Subject) => {
    return subject.totalChapters > 0 ? (subject.completedChapters / subject.totalChapters) * 100 : 0;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-slate-800 handwritten">Syllabus Tracker</h2>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]">
              <Plus className="h-4 w-4 mr-2" />
              Add Subject
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="handwritten">Add New Subject</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Subject Name</Label>
                <Input
                  id="name"
                  value={newSubject.name}
                  onChange={(e) => setNewSubject(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter subject name..."
                  className="handwritten"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Icon</Label>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {iconOptions.map(option => {
                      const Icon = iconMap[option.value];
                      return (
                        <Button
                          key={option.value}
                          variant={newSubject.icon === option.value ? "default" : "outline"}
                          size="sm"
                          onClick={() => setNewSubject(prev => ({ ...prev, icon: option.value }))}
                          className="p-2"
                        >
                          <Icon className="h-4 w-4" />
                        </Button>
                      );
                    })}
                  </div>
                </div>
                
                <div>
                  <Label>Color</Label>
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    {colorOptions.map(option => (
                      <Button
                        key={option.value}
                        variant={newSubject.color === option.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setNewSubject(prev => ({ ...prev, color: option.value }))}
                        className="p-2"
                      >
                        <div className={`w-4 h-4 rounded-full bg-${option.value}`} />
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
              
              <div>
                <Label>Chapters/Topics</Label>
                <div className="flex space-x-2 mt-2">
                  <Input
                    value={newChapter}
                    onChange={(e) => setNewChapter(e.target.value)}
                    placeholder="Add a chapter..."
                    onKeyPress={(e) => e.key === 'Enter' && handleAddChapter()}
                  />
                  <Button onClick={handleAddChapter} size="sm">Add</Button>
                </div>
                <div className="mt-2 space-y-1">
                  {newSubject.chapters.map((chapter, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                      <span className="text-sm">{chapter}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveChapter(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        ×
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
              
              <Button 
                onClick={handleAddSubject}
                className="w-full bg-[var(--journal-blue)] hover:bg-[var(--journal-dark)]"
              >
                Add Subject
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Overall Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="handwritten">Overall Syllabus Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <Progress value={getOverallProgress()} className="mb-2" />
          <p className="text-sm text-slate-600">
            {getOverallProgress().toFixed(0)}% Complete 
            ({subjects.reduce((sum, s) => sum + s.completedChapters, 0)} of {subjects.reduce((sum, s) => sum + s.totalChapters, 0)} topics)
          </p>
        </CardContent>
      </Card>

      {/* Subjects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map((subject) => {
          const Icon = iconMap[subject.icon] || BookOpen;
          const progress = getSubjectProgress(subject);
          
          return (
            <Card key={subject.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium handwritten">{subject.name}</CardTitle>
                <Icon className={`h-5 w-5 text-${subject.color}`} />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Progress value={progress} className="mb-2" />
                    <p className="text-sm text-slate-600">
                      {progress.toFixed(0)}% Complete ({subject.completedChapters} of {subject.totalChapters} chapters)
                    </p>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    {subject.chapters.slice(0, 4).map((chapter) => (
                      <div key={chapter.id} className="flex items-center justify-between">
                        <span className="text-slate-600 truncate">{chapter.name}</span>
                        {chapter.completed ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        ) : (
                          <Circle className="h-4 w-4 text-slate-300" />
                        )}
                      </div>
                    ))}
                    {subject.chapters.length > 4 && (
                      <p className="text-xs text-slate-400">
                        +{subject.chapters.length - 4} more chapters
                      </p>
                    )}
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className={`w-full hover:bg-${subject.color.split('-')[0]}-50`}
                    onClick={() => setViewingSubject(subject)}
                  >
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}

        {/* Add Subject Card */}
        <Card 
          className="border-2 border-dashed border-slate-300 hover:border-[var(--journal-blue)] transition-colors cursor-pointer"
          onClick={() => setIsAddDialogOpen(true)}
        >
          <CardContent className="flex flex-col items-center justify-center h-full p-6 text-center">
            <Plus className="h-8 w-8 text-slate-400 mb-3" />
            <h3 className="font-semibold text-slate-600 handwritten mb-2">Add New Subject</h3>
            <p className="text-sm text-slate-500">Track progress for a new subject</p>
          </CardContent>
        </Card>
      </div>

      {/* Subject Details Modal */}
      {viewingSubject && (
        <Dialog open={!!viewingSubject} onOpenChange={() => setViewingSubject(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="handwritten flex items-center">
                {iconMap[viewingSubject.icon] && 
                  React.createElement(iconMap[viewingSubject.icon], { className: `h-5 w-5 text-${viewingSubject.color} mr-2` })
                }
                {viewingSubject.name} - Chapter Details
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Progress value={getSubjectProgress(viewingSubject)} className="mb-2" />
                <p className="text-sm text-slate-600">
                  {getSubjectProgress(viewingSubject).toFixed(0)}% Complete 
                  ({viewingSubject.completedChapters} of {viewingSubject.totalChapters} chapters)
                </p>
              </div>
              
              <div className="max-h-96 overflow-y-auto space-y-2">
                {viewingSubject.chapters.map((chapter) => (
                  <div key={chapter.id} className="flex items-center space-x-3 p-3 bg-slate-50 rounded-lg">
                    <Checkbox
                      checked={chapter.completed}
                      onCheckedChange={() => handleToggleChapter(viewingSubject.id, chapter.id)}
                      className="w-5 h-5"
                    />
                    <span className={`flex-1 ${chapter.completed ? 'line-through text-slate-500' : 'text-slate-700'}`}>
                      {chapter.name}
                    </span>
                    <Badge variant={chapter.completed ? "default" : "secondary"}>
                      {chapter.completed ? "Complete" : "Pending"}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
