export interface Task {
  id: string;
  title: string;
  subject: string;
  deadline?: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  color: string;
  chapters: Chapter[];
  totalChapters: number;
  completedChapters: number;
}

export interface Chapter {
  id: string;
  name: string;
  completed: boolean;
  topics?: Topic[];
}

export interface Topic {
  id: string;
  name: string;
  completed: boolean;
}

export interface Note {
  id: string;
  title?: string;
  content: string;
  tags: string[];
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  date: string;
  mood?: string;
}

export interface PrayerEntry {
  id: string;
  title: string;
  content: string;
  language: string;
  category: string;
}

export interface TimerSettings {
  focusDuration: number; // in minutes
  shortBreak: number;
  longBreak: number;
  longBreakInterval: number; // after how many sessions
  autoStartBreaks: boolean;
  autoStartPomodoros: boolean;
  notifications: boolean;
}

export interface TimerState {
  timeLeft: number; // in seconds
  isRunning: boolean;
  currentSession: 'focus' | 'shortBreak' | 'longBreak';
  sessionsCompleted: number;
  totalSessionsToday: number;
}

export interface StudyStats {
  totalStudyTime: number; // in minutes
  tasksCompleted: number;
  currentStreak: number;
  longestStreak: number;
  weeklyHours: number[];
  subjectProgress: { [key: string]: number };
}

export interface AppSettings {
  password: string;
  journalPassword: string;
  aiChatEnabled: boolean;
  motivationalQuotes: string[];
  currentQuoteIndex: number;
  lastQuoteDate: string;
}

export interface Reminder {
  id: string;
  title: string;
  time: string;
  date: string;
  taskId?: string;
  enabled: boolean;
}
