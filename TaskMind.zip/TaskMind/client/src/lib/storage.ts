import { Task, Subject, Note, JournalEntry, PrayerEntry, TimerSettings, TimerState, StudyStats, AppSettings, Reminder } from '@/types';

const STORAGE_KEYS = {
  TASKS: 'lakshya_tasks',
  SUBJECTS: 'lakshya_subjects',
  NOTES: 'lakshya_notes',
  JOURNAL: 'lakshya_journal',
  PRAYERS: 'lakshya_prayers',
  TIMER_SETTINGS: 'lakshya_timer_settings',
  TIMER_STATE: 'lakshya_timer_state',
  STUDY_STATS: 'lakshya_study_stats',
  APP_SETTINGS: 'lakshya_app_settings',
  REMINDERS: 'lakshya_reminders',
} as const;

// Encryption helpers for password-protected sections
const encrypt = (text: string, password: string): string => {
  // Simple encryption - in a real app, use proper encryption
  return btoa(text + password);
};

const decrypt = (encryptedText: string, password: string): string => {
  try {
    const decrypted = atob(encryptedText);
    if (decrypted.endsWith(password)) {
      return decrypted.slice(0, -password.length);
    }
    throw new Error('Invalid password');
  } catch {
    throw new Error('Invalid password');
  }
};

export class LocalStorage {
  static get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch {
      return defaultValue;
    }
  }

  static set<T>(key: string, value: T): void {
    localStorage.setItem(key, JSON.stringify(value));
  }

  static remove(key: string): void {
    localStorage.removeItem(key);
  }

  static clear(): void {
    localStorage.clear();
  }
}

export class TaskStorage {
  static getTasks(): Task[] {
    return LocalStorage.get(STORAGE_KEYS.TASKS, []);
  }

  static saveTasks(tasks: Task[]): void {
    LocalStorage.set(STORAGE_KEYS.TASKS, tasks);
  }

  static addTask(task: Omit<Task, 'id' | 'createdAt'>): Task {
    const tasks = this.getTasks();
    const newTask: Task = {
      ...task,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    tasks.push(newTask);
    this.saveTasks(tasks);
    return newTask;
  }

  static updateTask(id: string, updates: Partial<Task>): void {
    const tasks = this.getTasks();
    const index = tasks.findIndex(task => task.id === id);
    if (index !== -1) {
      tasks[index] = { ...tasks[index], ...updates };
      this.saveTasks(tasks);
    }
  }

  static deleteTask(id: string): void {
    const tasks = this.getTasks();
    const filteredTasks = tasks.filter(task => task.id !== id);
    this.saveTasks(filteredTasks);
  }
}

export class SubjectStorage {
  static getSubjects(): Subject[] {
    return LocalStorage.get(STORAGE_KEYS.SUBJECTS, []);
  }

  static saveSubjects(subjects: Subject[]): void {
    LocalStorage.set(STORAGE_KEYS.SUBJECTS, subjects);
  }

  static addSubject(subject: Omit<Subject, 'id'>): Subject {
    const subjects = this.getSubjects();
    const newSubject: Subject = {
      ...subject,
      id: Date.now().toString(),
    };
    subjects.push(newSubject);
    this.saveSubjects(subjects);
    return newSubject;
  }

  static updateSubject(id: string, updates: Partial<Subject>): void {
    const subjects = this.getSubjects();
    const index = subjects.findIndex(subject => subject.id === id);
    if (index !== -1) {
      subjects[index] = { ...subjects[index], ...updates };
      this.saveSubjects(subjects);
    }
  }

  static deleteSubject(id: string): void {
    const subjects = this.getSubjects();
    const filteredSubjects = subjects.filter(subject => subject.id !== id);
    this.saveSubjects(filteredSubjects);
  }
}

export class NoteStorage {
  static getNotes(): Note[] {
    return LocalStorage.get(STORAGE_KEYS.NOTES, []);
  }

  static saveNotes(notes: Note[]): void {
    LocalStorage.set(STORAGE_KEYS.NOTES, notes);
  }

  static addNote(note: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>): Note {
    const notes = this.getNotes();
    const now = new Date().toISOString();
    const newNote: Note = {
      ...note,
      id: Date.now().toString(),
      createdAt: now,
      updatedAt: now,
    };
    notes.unshift(newNote);
    this.saveNotes(notes);
    return newNote;
  }

  static updateNote(id: string, updates: Partial<Note>): void {
    const notes = this.getNotes();
    const index = notes.findIndex(note => note.id === id);
    if (index !== -1) {
      notes[index] = { 
        ...notes[index], 
        ...updates, 
        updatedAt: new Date().toISOString() 
      };
      this.saveNotes(notes);
    }
  }

  static deleteNote(id: string): void {
    const notes = this.getNotes();
    const filteredNotes = notes.filter(note => note.id !== id);
    this.saveNotes(filteredNotes);
  }
}

export class JournalStorage {
  static getEntries(password: string): JournalEntry[] {
    try {
      const encrypted = localStorage.getItem(STORAGE_KEYS.JOURNAL);
      if (!encrypted) return [];
      const decrypted = decrypt(encrypted, password);
      return JSON.parse(decrypted);
    } catch {
      throw new Error('Invalid password');
    }
  }

  static saveEntries(entries: JournalEntry[], password: string): void {
    const encrypted = encrypt(JSON.stringify(entries), password);
    localStorage.setItem(STORAGE_KEYS.JOURNAL, encrypted);
  }

  static addEntry(entry: Omit<JournalEntry, 'id'>, password: string): JournalEntry {
    const entries = this.getEntries(password);
    const newEntry: JournalEntry = {
      ...entry,
      id: Date.now().toString(),
    };
    entries.unshift(newEntry);
    this.saveEntries(entries, password);
    return newEntry;
  }

  static updateEntry(id: string, updates: Partial<JournalEntry>, password: string): void {
    const entries = this.getEntries(password);
    const index = entries.findIndex(entry => entry.id === id);
    if (index !== -1) {
      entries[index] = { ...entries[index], ...updates };
      this.saveEntries(entries, password);
    }
  }

  static deleteEntry(id: string, password: string): void {
    const entries = this.getEntries(password);
    const filteredEntries = entries.filter(entry => entry.id !== id);
    this.saveEntries(filteredEntries, password);
  }
}

export class PrayerStorage {
  static getPrayers(): PrayerEntry[] {
    return LocalStorage.get(STORAGE_KEYS.PRAYERS, []);
  }

  static savePrayers(prayers: PrayerEntry[]): void {
    LocalStorage.set(STORAGE_KEYS.PRAYERS, prayers);
  }

  static addPrayer(prayer: Omit<PrayerEntry, 'id'>): PrayerEntry {
    const prayers = this.getPrayers();
    const newPrayer: PrayerEntry = {
      ...prayer,
      id: Date.now().toString(),
    };
    prayers.push(newPrayer);
    this.savePrayers(prayers);
    return newPrayer;
  }

  static updatePrayer(id: string, updates: Partial<PrayerEntry>): void {
    const prayers = this.getPrayers();
    const index = prayers.findIndex(prayer => prayer.id === id);
    if (index !== -1) {
      prayers[index] = { ...prayers[index], ...updates };
      this.savePrayers(prayers);
    }
  }

  static deletePrayer(id: string): void {
    const prayers = this.getPrayers();
    const filteredPrayers = prayers.filter(prayer => prayer.id !== id);
    this.savePrayers(filteredPrayers);
  }
}

export class TimerStorage {
  static getSettings(): TimerSettings {
    return LocalStorage.get(STORAGE_KEYS.TIMER_SETTINGS, {
      focusDuration: 25,
      shortBreak: 5,
      longBreak: 30,
      longBreakInterval: 4,
      autoStartBreaks: false,
      autoStartPomodoros: false,
      notifications: true,
    });
  }

  static saveSettings(settings: TimerSettings): void {
    LocalStorage.set(STORAGE_KEYS.TIMER_SETTINGS, settings);
  }

  static getState(): TimerState {
    return LocalStorage.get(STORAGE_KEYS.TIMER_STATE, {
      timeLeft: 25 * 60,
      isRunning: false,
      currentSession: 'focus' as const,
      sessionsCompleted: 0,
      totalSessionsToday: 0,
    });
  }

  static saveState(state: TimerState): void {
    LocalStorage.set(STORAGE_KEYS.TIMER_STATE, state);
  }
}

export class StatsStorage {
  static getStats(): StudyStats {
    return LocalStorage.get(STORAGE_KEYS.STUDY_STATS, {
      totalStudyTime: 0,
      tasksCompleted: 0,
      currentStreak: 0,
      longestStreak: 0,
      weeklyHours: [0, 0, 0, 0, 0, 0, 0],
      subjectProgress: {},
    });
  }

  static saveStats(stats: StudyStats): void {
    LocalStorage.set(STORAGE_KEYS.STUDY_STATS, stats);
  }

  static updateStats(updates: Partial<StudyStats>): void {
    const currentStats = this.getStats();
    const newStats = { ...currentStats, ...updates };
    this.saveStats(newStats);
  }
}

export class AppSettingsStorage {
  static getSettings(): AppSettings {
    const defaultQuotes = [
      "AIR 1 is nowhere around if you don't lock in. Every moment counts towards your dream.",
      "You either want it, or you don't. There's no middle ground in excellence.",
      "Success is not just about intelligence; it's about persistence and consistency.",
      "Your future self is watching. Make them proud with today's efforts.",
      "The pain of discipline weighs ounces, but the pain of regret weighs tons.",
      "Champions are made when nobody's watching. Keep grinding.",
      "Every expert was once a beginner. Every pro was once an amateur."
    ];

    return LocalStorage.get(STORAGE_KEYS.APP_SETTINGS, {
      password: '',
      journalPassword: '',
      aiChatEnabled: false,
      motivationalQuotes: defaultQuotes,
      currentQuoteIndex: 0,
      lastQuoteDate: '',
    });
  }

  static saveSettings(settings: AppSettings): void {
    LocalStorage.set(STORAGE_KEYS.APP_SETTINGS, settings);
  }

  static getDailyQuote(): string {
    const settings = this.getSettings();
    const today = new Date().toDateString();
    
    if (settings.lastQuoteDate !== today) {
      // Update to next quote
      const nextIndex = (settings.currentQuoteIndex + 1) % settings.motivationalQuotes.length;
      settings.currentQuoteIndex = nextIndex;
      settings.lastQuoteDate = today;
      this.saveSettings(settings);
    }
    
    return settings.motivationalQuotes[settings.currentQuoteIndex];
  }
}

export class ReminderStorage {
  static getReminders(): Reminder[] {
    return LocalStorage.get(STORAGE_KEYS.REMINDERS, []);
  }

  static saveReminders(reminders: Reminder[]): void {
    LocalStorage.set(STORAGE_KEYS.REMINDERS, reminders);
  }

  static addReminder(reminder: Omit<Reminder, 'id'>): Reminder {
    const reminders = this.getReminders();
    const newReminder: Reminder = {
      ...reminder,
      id: Date.now().toString(),
    };
    reminders.push(newReminder);
    this.saveReminders(reminders);
    return newReminder;
  }

  static updateReminder(id: string, updates: Partial<Reminder>): void {
    const reminders = this.getReminders();
    const index = reminders.findIndex(reminder => reminder.id === id);
    if (index !== -1) {
      reminders[index] = { ...reminders[index], ...updates };
      this.saveReminders(reminders);
    }
  }

  static deleteReminder(id: string): void {
    const reminders = this.getReminders();
    const filteredReminders = reminders.filter(reminder => reminder.id !== id);
    this.saveReminders(filteredReminders);
  }
}
