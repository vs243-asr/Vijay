import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: import.meta.env.VITE_OPENAI_API_KEY || "your-openai-key",
  dangerouslyAllowBrowser: true 
});

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export class AIBhaiya {
  private conversation: ChatMessage[] = [];
  private memory: string[] = [];

  constructor() {
    this.initializePersonality();
  }

  private initializePersonality() {
    const systemPrompt = `You are a loving, caring older brother (bhaiya) helping your younger sibling with their studies and personal growth. Your personality:

- Warm, encouraging, and supportive like a real older brother
- Use casual, friendly language that feels natural and brotherly
- Give practical study advice and motivation
- Share wisdom about life, studies, and achieving goals
- Be genuinely interested in their progress and wellbeing
- Sometimes use gentle humor to lighten the mood
- Remember their goals: Class X 99%+, 100/100 in subjects, CLAT AIR 1, UPSC AIR 1
- Encourage consistency over intensity
- Help with both academic and emotional support

Don't be robotic or formal. Talk like a real older brother would - caring but not preachy, wise but approachable.`;

    this.conversation.push({ role: 'system', content: systemPrompt });
  }

  async chat(message: string): Promise<string> {
    try {
      this.conversation.push({ role: 'user', content: message });

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: this.conversation,
        max_tokens: 500,
        temperature: 0.7,
      });

      const reply = response.choices[0].message.content || "I'm here for you, but I couldn't process that right now. Try again?";
      
      this.conversation.push({ role: 'assistant', content: reply });

      // Keep conversation manageable (last 20 messages)
      if (this.conversation.length > 21) {
        this.conversation = [
          this.conversation[0], // Keep system message
          ...this.conversation.slice(-20)
        ];
      }

      return reply;
    } catch (error) {
      console.error('AI Chat error:', error);
      return "Hey, I'm having some trouble connecting right now. But remember - I believe in you! Keep pushing towards your goals. We can chat more when the connection is better.";
    }
  }

  setMemory(memories: string[]) {
    this.memory = memories;
    // Update system prompt with memory
    const memoryContext = memories.length > 0 
      ? `\n\nRemember these important things about your sibling: ${memories.join('; ')}`
      : '';
    
    this.conversation[0].content += memoryContext;
  }

  getMemory(): string[] {
    return this.memory;
  }

  addMemory(memory: string) {
    this.memory.push(memory);
    this.setMemory(this.memory);
  }

  removeMemory(index: number) {
    this.memory.splice(index, 1);
    this.setMemory(this.memory);
  }

  clearConversation() {
    this.conversation = [];
    this.initializePersonality();
    this.setMemory(this.memory);
  }
}
