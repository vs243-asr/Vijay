import { useState } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navigation from "@/components/Navigation";
import Dashboard from "@/components/Dashboard";
import Timer from "@/components/Timer";
import Tasks from "@/components/Tasks";
import Syllabus from "@/components/Syllabus";
import Notes from "@/components/Notes";
import Progress from "@/components/Progress";
import ProtectedModal from "@/components/ProtectedModal";
import Journal from "@/components/Journal";
import AIChat from "@/components/AIChat";
import Prayer from "@/components/Prayer";

export type TabType = 'dashboard' | 'timer' | 'tasks' | 'syllabus' | 'notes' | 'progress' | 'journal' | 'aichat' | 'prayer';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [protectedModal, setProtectedModal] = useState<{
    isOpen: boolean;
    type: 'journal' | 'aichat' | null;
    password: string;
  }>({
    isOpen: false,
    type: null,
    password: ''
  });

  const handleProtectedAccess = (type: 'journal' | 'aichat') => {
    setProtectedModal({
      isOpen: true,
      type,
      password: ''
    });
  };

  const handleProtectedUnlock = (password: string) => {
    setProtectedModal(prev => ({ ...prev, password }));
    setActiveTab(protectedModal.type!);
    setProtectedModal({ isOpen: false, type: null, password: '' });
  };

  const handleProtectedClose = () => {
    setProtectedModal({ isOpen: false, type: null, password: '' });
  };

  const renderActiveTab = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard onNavigate={setActiveTab} onProtectedAccess={handleProtectedAccess} />;
      case 'timer':
        return <Timer />;
      case 'tasks':
        return <Tasks />;
      case 'syllabus':
        return <Syllabus />;
      case 'notes':
        return <Notes onProtectedAccess={handleProtectedAccess} />;
      case 'progress':
        return <Progress />;
      case 'journal':
        return <Journal password={protectedModal.password} />;
      case 'aichat':
        return <AIChat password={protectedModal.password} />;
      case 'prayer':
        return <Prayer />;
      default:
        return <Dashboard onNavigate={setActiveTab} onProtectedAccess={handleProtectedAccess} />;
    }
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-slate-50">
          <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
          
          <main className="max-w-7xl mx-auto px-4 py-6">
            <div className="fade-in">
              {renderActiveTab()}
            </div>
          </main>

          <ProtectedModal
            isOpen={protectedModal.isOpen}
            type={protectedModal.type}
            onUnlock={handleProtectedUnlock}
            onClose={handleProtectedClose}
          />
        </div>
        
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
